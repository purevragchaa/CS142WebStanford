import React from 'react';
import {
  Typography, Divider,
} from '@material-ui/core';
import { HashRouter, Link, Route, useParams } from 'react-router-dom';
import './userDetail.css';
import UserPhotos from '../userPhotos/userPhotos';

class UserDetail extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      users: window.cs142models.userListModel(),
    }
    
  }
  render() {
    const index = window.cs142models.userModel(this.props.match.params.userId);
    // console.log( "===============>");
    // console.log( index );

    return (
      <div>
        <Typography variant="h5"> {index.first_name} {index.last_name}</Typography>
          <Typography variant="subtitle1"> 
            <b>Address: </b>
            {index.location} 
          </Typography>
          <Typography variant="body1">
            <b>Occupation: </b> 
            {index.occupation}
          </Typography>
          <Typography variant="body1">
            <b>Description: </b> 
            {index.description}
          </Typography>
          <Divider />
          <HashRouter>
            <Link to={`/photos/${index._id}`}>Photos</Link>
          </HashRouter>
      </div>
    );
  }
}

export default UserDetail;
