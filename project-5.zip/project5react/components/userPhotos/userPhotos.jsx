import React from 'react';
import {
  Paper,
  Typography,
  Divider,
  List,
  ListItem,
} from '@material-ui/core';
import { HashRouter, Link, Router } from 'react-router-dom';
import './userPhotos.css';
import UserList2 from '../userlist2/userList2';

/**
 * Define UserPhotos, a React componment of CS142 project #5
 */
class UserPhotos extends React.Component {
  constructor(props) {
    super(props);
  }

  

  render() {
    const photos = window.cs142models.photoOfUserModel(this.props.match.params.userId);
    // console.log( "===============>");
    // console.log(photos);
    let writedComment;
    let c;
    // console.log(writedComment);
    
    return (
      <div>
        {
        photos.map(( element, index) => (
          writedComment = element.comments,
          c = writedComment != undefined,
          // console.log("comment_id",writedComment),
          <Paper key={index}>
            <Typography>
              {element.date_time}
            </Typography>
            <img style={{ width: "50%", height: "60%" }}
              src={'/../../images/' + element.file_name}
            />
            <div style={{ width: "50%", height: "60%" }}>
              { c ?
                writedComment.map((commentIndex, index) =>(
                  <List key={index}>
                    {/* {console.log("=======",commentIndex)} */}
                    {/* {console.log("user_id",commentIndex.user._id)} */}

                    <Link to={`/users/${commentIndex.user._id}`}>{commentIndex.user.first_name} </Link> 
                    <ListItem>                                           
                      { commentIndex.comment}
                    </ListItem> 
                    <ListItem>{commentIndex.date_time}</ListItem>
                  </List>
                ))
                : <p>no comment</p>
              }
            </div>
            <Divider/>
          </Paper>                                             
        ))
        }       
      </div>
    );
  }
}

export default UserPhotos;
