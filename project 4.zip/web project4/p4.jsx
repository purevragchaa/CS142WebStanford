import React from 'react';
import ReactDOM from 'react-dom';

import Switch from './components/switch/switch';


ReactDOM.render(
  <Switch/>,
  document.getElementById('reactapp'),
);
