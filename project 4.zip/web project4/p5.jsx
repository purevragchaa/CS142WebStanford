import React from 'react';
import ReactDOM from 'react-dom';
import Header from './components/Header/header';


ReactDOM.render(
  <Header/>,
  document.getElementById('reactapp'),
);